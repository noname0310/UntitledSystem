﻿using System.Collections.Generic;
using System;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using UnityEngine;
using Oxide.Core;
using Oxide.Core.Configuration;
using Oxide.Core.Plugins;
using Oxide.Core.Libraries.Covalence;
using Rust;

namespace Oxide.Plugins
{
    [Info("UntitleSystem", "noname", "2.3.6")]
    [Description("Serv Plugin For UntitledServer.")]
    class UntitleSystem : RustPlugin
    {
        [PluginReference]
        readonly Plugin UpdateNotice;
        DynamicConfigFile dataFile;

        private new void LoadDefaultConfig()
        {
            PrintWarning("Creating a new configuration file");
            Config.Clear();

            Config["ServerName"] = "DefaultServerName(Wiped: {0})";
            Config["UseCustomServerName"] = false;

            SaveConfig();
        }

        void OnServerInitialized()
        {
            permission.RegisterPermission("untitlesystem.threeom", this);
            permission.RegisterPermission("untitlesystem.fivem", this);
            permission.RegisterPermission("untitlesystem.halfh", this);
            permission.RegisterPermission("untitlesystem.sixh", this);
            permission.RegisterPermission("untitlesystem.threeh", this);
            permission.RegisterPermission("untitlesystem.oneh", this);

            try
            {
                dataFile = Interface.Oxide.DataFileSystem.GetDatafile("UntitleSystem");
                dataFile["reboot"] = false;
                dataFile["shutdown"] = false;
                dataFile["quit"] = false;
                dataFile["ServerVer"] = UpdateNotice.Call<int>("GetServerVersion");
                if(dataFile["LastResetDay"] == null)
                {             
                    dataFile["LastResetDay"] = null;
                }
                dataFile.Save();
            }
            catch
            {
                Puts("DataReadError");
            }

            string SetServerNameCommand;

            if(Config["UseCustomServerName"].ToString() == "True")
            {
                if(!(dataFile["LastResetDay"] == null))
                {
                    SetServerNameCommand = @"server.hostname """ + string.Format(Config["ServerName"].ToString(), dataFile["LastResetDay"].ToString()) + @"""";
                    covalence.Server.Command(SetServerNameCommand);
                }
                else
                {
                    SetServerNameCommand = @"server.hostname """ + string.Format(Config["ServerName"].ToString(), "--.--") + @"""";
                    covalence.Server.Command(SetServerNameCommand);
                }
            }

            timer.Every(2, timer_Tick);
        }

        // 매 2초마다
        void timer_Tick()
        {            
            try
            {
                dataFile = Interface.Oxide.DataFileSystem.GetDatafile("UntitleSystem");
                dataFile["ServerVer"] = UpdateNotice.Call<int>("GetServerVersion");
                dataFile.Save();
                if(dataFile["quit"].ToString() == "True")
                {
                    //Puts("test");
                    dataFile["quit"] = false;
                    dataFile.Save();
                    covalence.Server.Command("quit");
                }
            }
            catch
            {
                Puts("데이터 파일을 읽는데 실패 하였습니다");
            }
        }

        [ConsoleCommand("reboot")]
        void SystemReboot(ConsoleSystem.Arg args)
        {
            Puts("rebooting...");
            BasePlayer player = args.Player();
            if (!player)
            {
                Puts("permission accessed");
                try
                {
                    this.covalence.Server.Command("server.save");
                    dataFile["reboot"] = true;
                    dataFile.Save();
                }
                catch
                {
                    Puts("ERROR PLZ TRYAGAIN");
                }
            }
            else
                Puts("permission denal");
        }

        [ConsoleCommand("shutdown")]
        void SystemShutDown(ConsoleSystem.Arg args)
        {
            Puts("shutdown reserved...");
            BasePlayer player = args.Player();
            if (!player)
            {
                Puts("permission accessed");
                try
                {
                    this.covalence.Server.Command("server.save");
                    dataFile["shutdown"] = true;
                    dataFile.Save();
                }
                catch
                {
                    Puts("ERROR PLZ TRYAGAIN");
                }
            }
            else
                Puts("permission denal");
        }
    }
}